import { Routes } from '@angular/router';
import { ListPkmComponent } from './components/poke/list-pkm/list-pkm.component';
import { DetailsPkmComponent } from './components/poke/details-pkm/details-pkm.component';
import { HomeComponent } from './components/home/home.component';

export const routes: Routes = [
    { path: 'home', component: HomeComponent },
    { path: 'listPoke', component: ListPkmComponent },
    { path: 'details-pkm/:urlPoke', component: DetailsPkmComponent },
    { path: '**', redirectTo: 'home' }
];
